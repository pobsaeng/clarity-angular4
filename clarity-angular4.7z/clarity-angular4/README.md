# Clarity and Angular 4 seed template

## Installation

```
git clone https://github.com/siteslave/clarity-angular4-web.git

cd clarity-angular4-web

npm i
```

## Running app

```
ng serve
```

app url `http://localhost:4200`  

username: `admin` and password: `admin`
## Building

```
ng build --prod
```

## Screen short

![screenshort](https://cloud.githubusercontent.com/assets/526890/25038133/3c1f2db4-2127-11e7-8277-c82ae611b98c.png)
![screenshort](https://cloud.githubusercontent.com/assets/526890/25038140/48452062-2127-11e7-9dd2-7749d587ea38.png)